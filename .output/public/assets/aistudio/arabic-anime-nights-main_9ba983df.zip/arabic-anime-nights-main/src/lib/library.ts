import { useSyncExternalStore } from "react";

export interface HistoryEntry {
  animeId: string;
  episodeId: string;
  positionSec: number;
  durationSec: number;
  /** Epoch ms. */
  updatedAt: number;
}

interface LibraryState {
  favorites: string[];
  history: HistoryEntry[];
}

const FAV_KEY = "anime-ug:favorites";
const HIST_KEY = "anime-ug:history";
const MAX_HISTORY = 200;

const serverSnapshot: LibraryState = { favorites: [], history: [] };

let state: LibraryState = { favorites: [], history: [] };
let hydrated = false;
const listeners = new Set<() => void>();

function hydrate() {
  if (hydrated || typeof window === "undefined") return;
  hydrated = true;
  try {
    state = {
      favorites: JSON.parse(localStorage.getItem(FAV_KEY) ?? "[]"),
      history: JSON.parse(localStorage.getItem(HIST_KEY) ?? "[]"),
    };
  } catch {
    state = { favorites: [], history: [] };
  }
}

function persist() {
  if (typeof window === "undefined") return;
  localStorage.setItem(FAV_KEY, JSON.stringify(state.favorites));
  localStorage.setItem(HIST_KEY, JSON.stringify(state.history));
}

function emit() {
  for (const listener of listeners) listener();
}

function subscribe(cb: () => void) {
  hydrate();
  listeners.add(cb);
  return () => listeners.delete(cb);
}

function getSnapshot(): LibraryState {
  if (!hydrated) {
    if (typeof window === "undefined") return serverSnapshot;
    hydrate();
  }
  return state;
}

function update(mutate: (draft: LibraryState) => void) {
  hydrate();
  const draft: LibraryState = { favorites: [...state.favorites], history: [...state.history] };
  mutate(draft);
  state = draft;
  persist();
  emit();
}

export function toggleFavorite(animeId: string) {
  update((draft) => {
    draft.favorites = draft.favorites.includes(animeId)
      ? draft.favorites.filter((id) => id !== animeId)
      : [animeId, ...draft.favorites];
  });
}

export function saveProgress(entry: HistoryEntry) {
  update((draft) => {
    draft.history = [
      entry,
      ...draft.history.filter(
        (h) => !(h.animeId === entry.animeId && h.episodeId === entry.episodeId),
      ),
    ].slice(0, MAX_HISTORY);
  });
}

export function clearHistory() {
  update((draft) => {
    draft.history = [];
  });
}

export function useLibrary(): LibraryState {
  return useSyncExternalStore(subscribe, getSnapshot, () => serverSnapshot);
}

export function getProgress(
  library: LibraryState,
  animeId: string,
  episodeId: string,
): HistoryEntry | undefined {
  return library.history.find((h) => h.animeId === animeId && h.episodeId === episodeId);
}
