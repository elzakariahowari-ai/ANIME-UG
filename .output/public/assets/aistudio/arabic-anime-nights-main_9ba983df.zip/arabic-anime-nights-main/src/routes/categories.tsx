import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { AnimeCard } from "@/components/AnimeCard";
import { EmptyState } from "@/components/EmptyState";
import { CATALOG, allGenres } from "@/lib/catalog";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/categories")({
  head: () => ({
    meta: [
      { title: "التصنيفات — ANIME UG" },
      { name: "description", content: "تصفّح أعمال ANIME UG حسب التصنيف." },
      { property: "og:title", content: "التصنيفات — ANIME UG" },
      { property: "og:description", content: "تصفّح الأعمال حسب التصنيف." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: CategoriesPage,
});

function CategoriesPage() {
  const genres = allGenres();
  const [selected, setSelected] = useState<string | null>(null);
  const filtered = selected ? CATALOG.filter((a) => a.genres.includes(selected)) : CATALOG;

  return (
    <div className="mx-auto max-w-2xl px-4 pt-4">
      <h1 className="font-display text-lg font-bold">التصنيفات</h1>

      <div className="scrollbar-hide -mx-4 mt-3 flex gap-2 overflow-x-auto px-4 pb-1">
        <button
          type="button"
          onClick={() => setSelected(null)}
          className={cn(
            "shrink-0 rounded-full border px-4 py-1.5 text-xs font-semibold transition-colors",
            selected === null
              ? "border-primary bg-primary text-primary-foreground"
              : "border-border bg-card text-muted-foreground hover:text-foreground",
          )}
        >
          الكل
        </button>
        {genres.map((genre) => (
          <button
            key={genre}
            type="button"
            onClick={() => setSelected(genre)}
            className={cn(
              "shrink-0 rounded-full border px-4 py-1.5 text-xs font-semibold transition-colors",
              selected === genre
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-card text-muted-foreground hover:text-foreground",
            )}
          >
            {genre}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyState title="لا أعمال في هذا التصنيف" description="جرّب تصنيفًا آخر." />
      ) : (
        <section className="mt-4 pb-6">
          <div className="grid grid-cols-2 gap-3">
            {filtered.map((anime) => (
              <AnimeCard key={anime.id} anime={anime} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
