import { createFileRoute } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { useRef, useState } from "react";
import { AnimeCard } from "@/components/AnimeCard";
import { EmptyState } from "@/components/EmptyState";
import { CATALOG, searchCatalog } from "@/lib/catalog";

export const Route = createFileRoute("/search")({
  head: () => ({
    meta: [
      { title: "البحث — ANIME UG" },
      { name: "description", content: "ابحث في أعمال ANIME UG بالاسم العربي أو الإنجليزي." },
      { property: "og:title", content: "البحث — ANIME UG" },
      { property: "og:description", content: "ابحث في أعمال ANIME UG." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SearchPage,
});

function SearchPage() {
  const [query, setQuery] = useState("");
  const results = query.trim() ? searchCatalog(query) : CATALOG;
  const inputRef = useRef<HTMLInputElement>(null);

  return (
    <div className="mx-auto max-w-2xl px-4 pt-4">
      <div className="relative">
        <Search className="absolute top-1/2 right-3.5 size-5 -translate-y-1/2 text-muted-foreground" />
        <input
          ref={inputRef}
          type="search"
          inputMode="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="ابحث بالاسم العربي أو الإنجليزي…"
          aria-label="البحث"
          className="w-full rounded-2xl border border-border bg-card py-3 pr-11 pl-4 text-sm outline-none transition-colors focus:border-primary/60"
        />
      </div>

      {query.trim() && results.length === 0 ? (
        <EmptyState
          title="لا توجد نتائج"
          description="لم نجد عملاً بهذا الاسم. لاحظ أن القائمة الحالية تجريبية ومحدودة من مصادر مفتوحة الترخيص."
        />
      ) : (
        <section className="mt-4 pb-6">
          <h1 className="mb-3 font-display text-lg font-bold">
            {query.trim() ? `النتائج (${results.length})` : "كل الأعمال"}
          </h1>
          <div className="grid grid-cols-2 gap-3">
            {results.map((anime) => (
              <AnimeCard key={anime.id} anime={anime} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
