import { createFileRoute, Link } from "@tanstack/react-router";
import { Heart } from "lucide-react";
import { AnimeCard } from "@/components/AnimeCard";
import { EmptyState } from "@/components/EmptyState";
import { getAnime } from "@/lib/catalog";
import { useLibrary } from "@/lib/library";

export const Route = createFileRoute("/favorites")({
  head: () => ({
    meta: [
      { title: "المفضلة — ANIME UG" },
      { name: "description", content: "الأعمال التي حفظتها في المفضلة داخل ANIME UG." },
      { property: "og:title", content: "المفضلة — ANIME UG" },
      { property: "og:description", content: "أعمالك المحفوظة." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: FavoritesPage,
});

function FavoritesPage() {
  const library = useLibrary();
  const favorites = library.favorites
    .map((id) => getAnime(id))
    .filter((a): a is NonNullable<typeof a> => Boolean(a));

  return (
    <div className="mx-auto max-w-2xl px-4 pt-4">
      <h1 className="font-display text-lg font-bold">المفضلة</h1>
      {favorites.length === 0 ? (
        <EmptyState
          title="قائمتك فارغة"
          description="اضغط على زر القلب في صفحة أي عمل لإضافته هنا."
          action={
            <Link
              to="/"
              className="rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground"
            >
              تصفّح الأعمال
            </Link>
          }
        />
      ) : (
        <section className="mt-4 pb-6">
          <div className="grid grid-cols-2 gap-3">
            {favorites.map((anime) => (
              <AnimeCard key={anime.id} anime={anime} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
