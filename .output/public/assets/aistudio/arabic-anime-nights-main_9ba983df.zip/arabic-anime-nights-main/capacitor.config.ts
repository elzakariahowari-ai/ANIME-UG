import type { CapacitorConfig } from "@capacitor/cli";

/**
 * Capacitor configuration for packaging ANIME UG as an Android APK.
 * See README.md → "تغليف التطبيق لنظام Android" for the exact steps.
 *
 * NOTE: `webDir` is a placeholder for the static export. The recommended flow
 * in the README points `server.url` at the published web build, because the
 * web app is a TanStack Start SSR app.
 */
const config: CapacitorConfig = {
  appId: "com.animeug.app",
  appName: "ANIME UG",
  webDir: "dist",
  server: {
    androidScheme: "https",
  },
};

export default config;
